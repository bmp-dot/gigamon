
. env_setup

./gvtapl $*
