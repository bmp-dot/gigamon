#!/bin/bash

# Creates a GRE or a VXLAN mirror to VSeries.
#
# Arguments:
#   - mirror_name
#   - tunnel_type
#   - ovs_bridge        (constructed name to pass to ovs)
#   - physical_intf     (physical intf, from which constructed name is built)
#   - key               (for gre, etc)
#   - local_ip          (ip of local egress interface)
#   - remote_ip         (ip of remote Vseries)
#   - eif               (egress interface)
#   - gw                (next hop to reach v-series)
#   - mtu
#   - dst_port          (port on VSeries to receive  mirrored traffic)
#   - vlan_tag          (vlan_tag of pkts going out the interface)

#echo $*

display_usage() {
  echo -e "\nUsage: $0 -n(--name) <mirror_name> -t(--tun_type) <gre|vxlan> -o(--ovs_bridge) <ovs-bridge>\
       -p(--phy_if) <phy_intf> -k(--key) <GRE Key> -l(--local_ip) -r(--remote_ip) <Vseries-IP> -e(--eif) <Egress Interface>\
       -g(--gw) <Gateway> -m(--mtu) <MTU> -d(--dst_port) <DST PORT> -v(--vlan_tag) <VLAN>\n"

  echo -e "Example1: ./create_ovs_mirror.sh -n GigOvsMirror -t gre -o br-int -p gre0 -k 0 -l 10.2.5.9 -r 1.2.3.4\
                     -e vlan2020 -g 172.20.20.1 -m 1450 -d 4789 -v 2020\n"
  echo -e "Example2: ./create_ovs_mirror.sh --name GigOvsMirror --tun_type gre --ovs_bridge br-int\
                     --phy_if gre0 --key 0 --local_ip 10.2.5.9 --remote_ip 1.2.3.4 --eif vlan2020 --gw 172.20.20.1\
                     --mtu 1450 --dst_port 4789 --vlan_tag 2020\n"
}

if [  $# -ne 26 ]
then
  display_usage
  exit 1
else
  while [ "$1" != "" ]; do
      PARAM="$1"
      shift
      VALUE="$1"

      case $PARAM in
          -h | --help)
              display_usage
              exit
              ;;
          -n | --name)
              mirror_name=$VALUE
              ;;
          -t | --tun_type)
              tun_type=$VALUE
              ;;
          -o | --ovs_bridge)
              ovs_bridge=$VALUE
              ;;
          -p | --phy_if)
              phy_if=$VALUE
                ;;
          -k | --key)
              key=$VALUE
                ;;
          -l | --local_ip)
              local_ip=$VALUE
                ;;
          -r | --remote_ip)
              remote_ip=$VALUE
                ;;
          -e | --eif)
              tun_eif=$VALUE
                ;;
          -g | --gw)
              tun_gw=$VALUE
                ;;
          -m | --mtu)
              mtu=$VALUE
                ;;
          -d | --dst_port)
              dst_port=$VALUE
                ;;
          -v | --vlan_tag)
              vlan_tag=$VALUE
                ;;
          -w | --ip_ver)
              is_ipv6=$VALUE
                ;;
          *)
              echo "ERROR: unknown parameter \"$PARAM\""
              display_usage
              exit 1
              ;;
      esac
      shift
  done
fi

#echo "Mirror Name:" $mirror_name
#echo "OVS Bridge:" $ovs_bridge
#echo "Phy If:" $phy_if
#echo "Key:" $key
#echo "Remote IP:" $remote_ip
#echo "MTU:" $mtu
#echo "Dst Port:" $dst_port
#echo "Tunnel Type:" $tun_type

if [ "$tun_type" == "1" ]
then
  if [ "$is_ipv6" == "1" ]
  then
    tunnel_type="ip6gre"
  else
    tunnel_type="gre"
  fi
  if [ "$vlan_tag" == "0" ]
  then
  ovs-vsctl add-port $ovs_bridge $phy_if -- set Interface $phy_if type=$tunnel_type options:local_ip=$local_ip options:remote_ip=$remote_ip\
                     options:packet_type=legacy_l2 options:key=$key -- --id=@p get port $phy_if   -- --id=@m create mirror\
                     name=$mirror_name output-port=@p -- set bridge $ovs_bridge mirrors=@m
  else
  ovs-vsctl add-port $ovs_bridge $phy_if tag=$vlan_tag -- set Interface $phy_if type=$tunnel_type options:local_ip=$local_ip options:remote_ip=$remote_ip\
                     options:packet_type=legacy_l2 options:key=$key -- --id=@p get port $phy_if   -- --id=@m create mirror\
                     name=$mirror_name output-port=@p -- set bridge $ovs_bridge mirrors=@m
  fi
elif [ "$tun_type" == "2" ]
then
  tunnel_type="vxlan"
  if [ "$vlan_tag" == "0" ]
  then
  ovs-vsctl add-port $ovs_bridge $phy_if -- set Interface $phy_if type=$tunnel_type options:local_ip=$local_ip options:remote_ip=$remote_ip\
                     options:key=$key option:dst_port=$dst_port -- --id=@p get port $phy_if   -- --id=@m create mirror\
                     name=$mirror_name output-port=@p -- set bridge $ovs_bridge mirrors=@m
  else
  ovs-vsctl add-port $ovs_bridge $phy_if tag=$vlan_tag -- set Interface $phy_if type=$tunnel_type options:local_ip=$local_ip options:remote_ip=$remote_ip\
                     options:key=$key option:dst_port=$dst_port -- --id=@p get port $phy_if   -- --id=@m create mirror\
                     name=$mirror_name output-port=@p -- set bridge $ovs_bridge mirrors=@m
  fi
fi

rc=$?
if [ $rc -ne 0 ]
then
exit $rc
fi

# Delete the Route from ovs-pipeline if it exists
# TODO: Enhance to check if the route exists then delete.
if [ "$is_ipv6" == "1" ]
then
  ovs-appctl ovs/route/del $remote_ip/128
  # Add the Route for remote_ip
  ovs-appctl ovs/route/add $remote_ip/128 $tun_eif $tun_gw
else
  ovs-appctl ovs/route/del $remote_ip/32
  # Add the Route for remote_ip
  ovs-appctl ovs/route/add $remote_ip/32 $tun_eif $tun_gw
fi

rc=$?
exit $rc
