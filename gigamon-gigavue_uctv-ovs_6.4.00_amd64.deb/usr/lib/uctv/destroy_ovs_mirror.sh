#!/bin/bash

# Destroys the GRE or a VXLAN mirror to VSeries.
#
# Arguments:
#   - mirror_name
#   - ovs_bridge        (constructed name to pass to ovs)
#   - physical_intf     (physical intf, from which constructed name is built)

#echo $*

display_usage() {
  echo -e "\nUsage: $0 -n(--name) <mirror_name> -o(--ovs_bridge) <ovs-bridge> -p(--phy_if) <phy_intf>\n"

  echo -e "Example1: ./destroy_ovs_mirror.sh -n GigOvsMirror -o br-int -p gre0\n"
  echo -e "Example2: ./destroy_ovs_mirror.sh --name GigOvsMirror --ovs_bridge br-int --phy_if gre0\n"
}

if [  $# -ne 6 ]
then
  display_usage
  exit 1
else
  while [ "$1" != "" ]; do
      PARAM="$1"
      shift
      VALUE="$1"

      case $PARAM in
          -h | --help)
              display_usage
              exit
              ;;
          -n | --name)
              mirror_name=$VALUE
              ;;
          -o | --ovs_bridge)
              ovs_bridge=$VALUE
              ;;
          -p | --phy_if)
              phy_if=$VALUE
                ;;
          *)
              echo "ERROR: unknown parameter \"$PARAM\""
              display_usage
              exit 1
              ;;
      esac
      shift
  done
fi


#echo "Mirror Name:" $mirror_name
#echo "Ovs bridge:" $ovs_bridge
#echo "Phy If:" $phy_if


ovs-vsctl del-port $ovs_bridge $phy_if
rc=$?

if [ $rc -ne 0 ]
then
  echo "Port deletion failed: cannot delete mirror $mirror_name"
fi

ovs-vsctl -- --id=@rec get Mirror $mirror_name \
              -- remove Bridge $ovs_bridge mirrors @rec

rc=$?
if [ $rc -ne 0 ]
then
  echo "Mirror deletion failed: cannot delete mirror $mirror_name"
fi
exit $rc

