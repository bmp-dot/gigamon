#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved.
#


GVTAP_AGENT_SERVER=$GVTAP_AGENT_PROG_DIR/uctvd
GVTAP_AGENT_CMD=$GVTAP_AGENT_PROG_DIR/uctvl


PID=`pidof $GVTAP_AGENT_SERVER`
if [ $PID > 0 ]; then
	# Destroy any existing interface mirrors
	MIRRORS=`$GVTAP_AGENT_CMD mirror-list`
	for MIRROR in $MIRRORS; do
		$GVTAP_AGENT_CMD mirror-destroy $MIRROR
		if [ $? -ne 0 ]; then
			echo "Warning: Could not destroy interface mirror: $MIRROR"
		fi
		
	done

	# Stop UCT-V
	$GVTAP_AGENT_CMD uctv-ctl --stop
	if [ $? -ne 0 ]; then
		echo "Error: UCT-V stop failure"
		exit 1
	fi

	# Wait for UCT_V to terminate
	sleep 2

	# Reset UCT-V
	$GVTAP_AGENT_CMD uctv-ctl --reset
	if [ $? -ne 0 ]; then
		echo "Error: UCT-V reset failure"
		exit 1
	fi
else
	echo "Error: UCT-V is not running"
	exit 1
fi

exit 0
