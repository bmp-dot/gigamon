#!/bin/bash
#
# Copyright (c) 2015 Gigamon Inc. All Rights Reserved.
#


GVTAP_AGENT_SERVER=$GVTAP_AGENT_PROG_DIR/uctvd
GVTAP_AGENT_CMD=$GVTAP_AGENT_PROG_DIR/uctvl


# Stop UCT-V iff running
PID=`pidof $GVTAP_AGENT_SERVER`
if [ $PID > 0 ]; then
	$GVTAP_AGENT_CMD uctv-ctl --stop
	if [ $? -ne 0 ]; then
		echo "Error: UCT-V stop failure"
		exit 1
	fi

	# Wait for UCT-V to terminate
	sleep 2
fi

# Start UCT-V 
$GVTAP_AGENT_CMD uctv-ctl --start
if [ $? -ne 0 ]; then
	echo "Error: UCT-V start failure"
	exit 1
fi

# Wait for UCT-V to become ready
sleep 2

exit 0
