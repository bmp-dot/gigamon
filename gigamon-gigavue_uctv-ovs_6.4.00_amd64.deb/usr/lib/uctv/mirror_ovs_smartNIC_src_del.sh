#!/bin/bash

# Deletes the src interface from the mirror created earlier.
# This will stop traffic from this interface to be
# sent/mirrored to VSeries.

# Arguments:
#   - mirror_name
#   - src_intf_uuid          (intf to delete from mirror)
#   - direction         (1=INGRESS, 2=EGRESS. Specified which dir to mirror)

#echo $*

display_usage() {
  echo -e "\nUsage: $0 -n(--name) <mirror_name> -s(--src_intf_uuid) <src_intf_uuid> -d(--direction) <direction>\n"

  echo -e "Example1: ./mirror_ovs_src_del.sh -n GigOvsMirror -s tapf1df1099-72 -d 1\n"
  echo -e "Example2: ./mirror_ovs_src_del.sh --name GigOvsMirror --src_intf_uuid tapf1df1099-72 --direction 1\n"
}

if [  $# -ne 6 ]
then
  display_usage
  exit 1
else
  while [ "$1" != "" ]; do
      PARAM="$1"
      shift
      VALUE="$1"

      case $PARAM in
          -h | --help)
              display_usage
              exit
                ;;
          -n | --name)
              mirror_name=$VALUE
                ;;
          -s | --src_intf_uuid)
              src_intf_uuid=$VALUE
                ;;
          -d | --direction)
              direction=$VALUE
                ;;
          *)
              echo "ERROR: unknown parameter \"$PARAM\""
              display_usage
              exit 1
              ;;
     esac
     shift
  done
fi

#echo "Mirror Name:" $mirror_name
#echo "Src intf:" $src_intf_uuid
#echo "Direction:" $direction


src_iface_mapping=$(ovs-vsctl --columns=name,external_ids --no-heading --format=table list interface | grep $src_intf_uuid | grep 'vm-')
if [ "$src_iface_mapping" == "" ]
then
    echo "src interface mapping not found!"
    exit 1
fi

src_intf=$(echo $src_iface_mapping | awk '{print $1}' | tr -d '"')
if [ "$src_intf" == "" ]
then
    echo "Invalid src interface!"
    exit 1
fi

# If direction is 1 then we have to delete an ingress port
# If direction is 2 then we have to delete an egress port

if [ "$direction" == "1" ]
then
  ovs-vsctl -- --id=@p1 get Port $src_intf  -- remove Mirror $mirror_name select-dst-port @p1
elif [ "$direction" == "2" ]
then
  ovs-vsctl -- --id=@p1 get Port $src_intf  -- remove Mirror $mirror_name select-src-port @p1
else
  echo "Invalid input:direction can only be 1 or 2"
fi

rc=$?
exit $rc
